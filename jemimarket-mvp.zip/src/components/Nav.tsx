"use client";

import Link from "next/link";
import { signOut, useSession } from "next-auth/react";

export default function Nav() {
  const { data: session, status } = useSession();

  return (
    <header className="border-b">
      <div className="mx-auto max-w-5xl px-4 py-3 flex items-center gap-4">
        <Link href="/" className="font-semibold">JemimaMarket</Link>

        <nav className="flex items-center gap-3 text-sm text-gray-700">
          <Link href="/sell" className="underline">Sell</Link>
          <Link href="/favorites" className="underline">Favorites</Link>
          <Link href="/inbox" className="underline">Inbox</Link>
          <Link href="/orders" className="underline">Orders</Link>
          <Link href="/me" className="underline">Profile</Link>
          <Link href="/seller/dashboard" className="underline">Seller</Link>
          <Link href="/admin/reports" className="underline">Admin</Link>
        </nav>

        <div className="ml-auto flex items-center gap-3 text-sm">
          {status === "loading" ? null : session ? (
            <>
              <span className="text-gray-600">@{session.user?.name}</span>
              <button className="px-3 py-1 rounded border hover:bg-gray-50" onClick={() => signOut({ callbackUrl: "/" })}>
                Sign out
              </button>
            </>
          ) : (
            <>
              <Link className="px-3 py-1 rounded border hover:bg-gray-50" href="/login">Log in</Link>
              <Link className="px-3 py-1 rounded bg-black text-white hover:opacity-90" href="/signup">Sign up</Link>
            </>
          )}
        </div>
      </div>
    </header>
  );
}
