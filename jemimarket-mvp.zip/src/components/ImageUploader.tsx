"use client";

import { useState } from "react";

type Props = { value: string[]; onChange: (urls: string[]) => void; max?: number };

const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp"]);

export default function ImageUploader({ value, onChange, max = 10 }: Props) {
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function uploadFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setErr(null);

    const picked = Array.from(files);
    if (value.length + picked.length > max) {
      setErr(`Max ${max} images.`);
      return;
    }
    for (const f of picked) {
      if (!ALLOWED.has(f.type)) return setErr("Only JPG, PNG, or WEBP images are supported.");
      if (f.size > MAX_BYTES) return setErr("Each image must be ≤ 8MB.");
    }

    setUploading(true);
    try {
      const next: string[] = [];
      for (const f of picked) {
        const presignRes = await fetch("/api/uploads/presign", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ filename: f.name, contentType: f.type }),
        });
        const presign = await presignRes.json();
        if (!presignRes.ok) throw new Error(presign.error ?? "Presign failed");

        const putRes = await fetch(presign.uploadUrl, {
          method: "PUT",
          headers: { "content-type": f.type },
          body: f,
        });
        if (!putRes.ok) throw new Error("Upload failed");

        next.push(presign.publicUrl);
      }
      onChange([...value, ...next]);
    } catch (e: any) {
      setErr(e.message ?? "Upload failed");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-3">
        <label className="inline-flex items-center gap-2 px-3 py-2 rounded border hover:bg-gray-50 cursor-pointer text-sm">
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            multiple
            className="hidden"
            onChange={(e) => uploadFiles(e.target.files)}
            disabled={uploading}
          />
          <span>{uploading ? "Uploading..." : "Add images"}</span>
        </label>

        <span className="text-sm text-gray-600">{value.length}/{max}</span>

        {value.length ? (
          <button type="button" className="text-sm underline text-gray-700" onClick={() => onChange([])} disabled={uploading}>
            Clear
          </button>
        ) : null}
      </div>

      {err ? <div className="text-sm text-red-600">{err}</div> : null}

      {value.length ? (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          {value.map((u) => (
            <div key={u} className="relative">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={u} alt="" className="h-24 w-full object-cover rounded border" />
              <button
                type="button"
                className="absolute top-1 right-1 bg-white/90 border rounded px-2 py-0.5 text-xs"
                onClick={() => onChange(value.filter((x) => x !== u))}
                disabled={uploading}
                title="Remove"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-sm text-gray-600">Upload up to {max} images.</div>
      )}
    </div>
  );
}
