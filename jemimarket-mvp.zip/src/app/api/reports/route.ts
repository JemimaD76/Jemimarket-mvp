import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { z } from "zod";

const schema = z.object({ listingId: z.string().optional(), reason: z.string().min(3).max(500) });

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { listingId, reason } = schema.parse(await req.json());

  const report = await prisma.report.create({
    data: { reporterId: (session as any).uid, listingId: listingId ?? null, reason },
  });

  return NextResponse.json({ report });
}
