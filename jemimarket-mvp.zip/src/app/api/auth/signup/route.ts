import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { z } from "zod";
import bcrypt from "bcrypt";

const schema = z.object({
  email: z.string().email(),
  handle: z.string().min(3).max(20).regex(/^[a-zA-Z0-9_]+$/),
  password: z.string().min(6).max(100),
});

export async function POST(req: Request) {
  const body = schema.parse(await req.json());

  const exists = await prisma.user.findFirst({
    where: { OR: [{ email: body.email }, { handle: body.handle }] },
  });
  if (exists) return NextResponse.json({ error: "Email or handle already in use." }, { status: 409 });

  const passwordHash = await bcrypt.hash(body.password, 12);
  await prisma.user.create({ data: { email: body.email, handle: body.handle, passwordHash } });

  return NextResponse.json({ ok: true });
}
