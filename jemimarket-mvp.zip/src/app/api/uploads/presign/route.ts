import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { z } from "zod";
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import crypto from "crypto";

const schema = z.object({ filename: z.string().min(1).max(200), contentType: z.string().min(3).max(200) });
const ALLOWED = new Set(["image/jpeg", "image/png", "image/webp"]);

function extFromContentType(ct: string) {
  if (ct === "image/jpeg") return "jpg";
  if (ct === "image/png") return "png";
  if (ct === "image/webp") return "webp";
  return "bin";
}

const s3 = new S3Client({
  region: process.env.S3_REGION!,
  endpoint: process.env.S3_ENDPOINT!,
  credentials: { accessKeyId: process.env.S3_ACCESS_KEY_ID!, secretAccessKey: process.env.S3_SECRET_ACCESS_KEY! },
  forcePathStyle: true,
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { filename, contentType } = schema.parse(await req.json());
  if (!ALLOWED.has(contentType)) return NextResponse.json({ error: "Unsupported file type" }, { status: 400 });

  const uid = (session as any).uid as string;

  const safeExt = extFromContentType(contentType);
  const rand = crypto.randomBytes(16).toString("hex");
  const key = `uploads/${uid}/${Date.now()}-${rand}.${safeExt}`;

  const bucket = process.env.S3_BUCKET!;
  const publicBase = process.env.S3_PUBLIC_BASE_URL!.replace(/\/$/, "");

  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    ContentType: contentType
    // NOTE: If your provider supports ACL public-read and you want it:
    // , ACL: "public-read"
  });

  const uploadUrl = await getSignedUrl(s3, command, { expiresIn: 60 });

  return NextResponse.json({ uploadUrl, key, publicUrl: `${publicBase}/${key}` });
}
