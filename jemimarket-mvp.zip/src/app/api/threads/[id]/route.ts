import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid;

  const thread = await prisma.thread.findUnique({
    where: { id: params.id },
    include: {
      listing: { include: { images: true, seller: { select: { handle: true } } } },
      messages: { orderBy: { createdAt: "asc" }, include: { sender: { select: { handle: true } } } },
      buyer: { select: { id: true, handle: true } },
      seller: { select: { id: true, handle: true } },
    },
  });

  if (!thread) return NextResponse.json({ error: "Thread not found" }, { status: 404 });
  if (thread.buyerId !== uid && thread.sellerId !== uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  return NextResponse.json({ thread });
}
