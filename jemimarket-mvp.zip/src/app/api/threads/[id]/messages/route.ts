import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { z } from "zod";

const schema = z.object({ body: z.string().min(1).max(2000) });

export async function POST(req: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid;
  const { body } = schema.parse(await req.json());

  const thread = await prisma.thread.findUnique({ where: { id: params.id } });
  if (!thread) return NextResponse.json({ error: "Thread not found" }, { status: 404 });
  if (thread.buyerId !== uid && thread.sellerId !== uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const msg = await prisma.message.create({ data: { threadId: thread.id, senderId: uid, body } });
  return NextResponse.json({ message: msg });
}
