import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { z } from "zod";

const schema = z.object({ listingId: z.string(), message: z.string().min(1).max(2000) });

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { listingId, message } = schema.parse(await req.json());
  const listing = await prisma.listing.findUnique({ where: { id: listingId } });
  if (!listing) return NextResponse.json({ error: "Listing not found" }, { status: 404 });

  const buyerId = (session as any).uid as string;
  const sellerId = listing.sellerId;

  if (buyerId === sellerId) return NextResponse.json({ error: "Cannot message yourself" }, { status: 400 });

  const result = await prisma.$transaction(async (tx) => {
    const existing = await tx.thread.findUnique({ where: { listingId_buyerId_sellerId: { listingId, buyerId, sellerId } } });
    const thread = existing ?? await tx.thread.create({ data: { listingId, buyerId, sellerId } });

    if (!existing) {
      await tx.listing.update({ where: { id: listingId }, data: { enquiriesCount: { increment: 1 } } }).catch(() => null);
    }

    await tx.message.create({ data: { threadId: thread.id, senderId: buyerId, body: message } });
    return thread;
  });

  return NextResponse.json({ threadId: result.id });
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid;

  const threads = await prisma.thread.findMany({
    where: { OR: [{ buyerId: uid }, { sellerId: uid }] },
    include: {
      listing: { include: { images: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
      buyer: { select: { handle: true } },
      seller: { select: { handle: true } },
    },
    orderBy: { createdAt: "desc" },
    take: 50,
  });

  return NextResponse.json({ threads });
}
