import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid;

  const user = await prisma.user.findUnique({
    where: { id: uid },
    select: { id: true, email: true, handle: true, role: true, createdAt: true, profileAnnouncement: true },
  });

  const listings = await prisma.listing.findMany({
    where: { sellerId: uid },
    include: { images: true },
    orderBy: { createdAt: "desc" },
    take: 200,
  });

  return NextResponse.json({ user, listings });
}
