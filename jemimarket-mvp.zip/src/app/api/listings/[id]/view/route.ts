import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function POST(_: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  const uid = session ? ((session as any).uid as string) : null;

  await prisma.$transaction(async (tx) => {
    await tx.listing.update({ where: { id: params.id }, data: { viewsCount: { increment: 1 } } }).catch(() => null);
    await tx.listingView.create({ data: { listingId: params.id, userId: uid ?? undefined } }).catch(() => null);
  });

  return NextResponse.json({ ok: true });
}
