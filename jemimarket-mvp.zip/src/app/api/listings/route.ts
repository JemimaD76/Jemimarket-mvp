import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";

function asInt(v: string | null, def: number, min: number, max: number) {
  const n = v ? Number(v) : NaN;
  if (!Number.isFinite(n)) return def;
  return Math.max(min, Math.min(max, Math.trunc(n)));
}

function asPence(v: string | null) {
  if (!v) return undefined;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return undefined;
  return Math.round(n * 100);
}

type Cursor =
  | { sort: "newest"; createdAt: string; id: string }
  | { sort: "price_asc"; pricePence: number; id: string }
  | { sort: "price_desc"; pricePence: number; id: string };

function decodeCursor(raw: string | null): Cursor | null {
  if (!raw) return null;
  try {
    const json = Buffer.from(raw, "base64url").toString("utf8");
    return JSON.parse(json);
  } catch {
    return null;
  }
}

function encodeCursor(c: Cursor) {
  return Buffer.from(JSON.stringify(c), "utf8").toString("base64url");
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);

  const q = (searchParams.get("q") ?? "").trim();
  const category = (searchParams.get("category") ?? "").trim();
  const brand = (searchParams.get("brand") ?? "").trim();
  const size = (searchParams.get("size") ?? "").trim();
  const condition = (searchParams.get("condition") ?? "").trim();
  const minPrice = asPence(searchParams.get("minPrice"));
  const maxPrice = asPence(searchParams.get("maxPrice"));

  const sort = (searchParams.get("sort") ?? (q ? "relevance" : "newest")).trim() as "newest" | "price_asc" | "price_desc" | "relevance";
  const pageSize = asInt(searchParams.get("pageSize"), 24, 6, 50);
  const cursor = decodeCursor(searchParams.get("cursor"));

  const baseWhere: any = {
    status: "ACTIVE",
    ...(q ? { OR: [
      { title: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
      { brand: { contains: q, mode: "insensitive" } },
    ] } : {}),
    ...(category ? { category: { contains: category, mode: "insensitive" } } : {}),
    ...(brand ? { brand: { contains: brand, mode: "insensitive" } } : {}),
    ...(size ? { size: { contains: size, mode: "insensitive" } } : {}),
    ...(condition ? { condition: { contains: condition, mode: "insensitive" } } : {}),
    ...((minPrice !== undefined || maxPrice !== undefined)
      ? { pricePence: { ...(minPrice !== undefined ? { gte: minPrice } : {}), ...(maxPrice !== undefined ? { lte: maxPrice } : {}) } }
      : {}),
  };

  let where: any = baseWhere;
  let orderBy: any[] = [];

  // For portability, relevance just uses createdAt desc after filtering (FTS ranking can be added via SQL migrations).
  const effectiveSort = sort === "relevance" ? "newest" : sort;

  if (effectiveSort === "newest") {
    orderBy = [{ createdAt: "desc" }, { id: "desc" }];
    if (cursor && cursor.sort === "newest") {
      where = { AND: [baseWhere, { OR: [
        { createdAt: { lt: new Date(cursor.createdAt) } },
        { createdAt: new Date(cursor.createdAt), id: { lt: cursor.id } }
      ]}]};
    }
  }

  if (effectiveSort === "price_asc") {
    orderBy = [{ pricePence: "asc" }, { id: "asc" }];
    if (cursor && cursor.sort === "price_asc") {
      where = { AND: [baseWhere, { OR: [
        { pricePence: { gt: cursor.pricePence } },
        { pricePence: cursor.pricePence, id: { gt: cursor.id } }
      ]}]};
    }
  }

  if (effectiveSort === "price_desc") {
    orderBy = [{ pricePence: "desc" }, { id: "desc" }];
    if (cursor && cursor.sort === "price_desc") {
      where = { AND: [baseWhere, { OR: [
        { pricePence: { lt: cursor.pricePence } },
        { pricePence: cursor.pricePence, id: { lt: cursor.id } }
      ]}]};
    }
  }

  const listings = await prisma.listing.findMany({
    where,
    orderBy,
    take: pageSize,
    include: { images: true, seller: { select: { id: true, handle: true } } },
  });

  const last = listings[listings.length - 1];
  let nextCursor: string | null = null;
  if (last) {
    if (effectiveSort === "newest") nextCursor = encodeCursor({ sort: "newest", createdAt: last.createdAt.toISOString(), id: last.id });
    else if (effectiveSort === "price_asc") nextCursor = encodeCursor({ sort: "price_asc", pricePence: last.pricePence, id: last.id });
    else nextCursor = encodeCursor({ sort: "price_desc", pricePence: last.pricePence, id: last.id });
  }

  return NextResponse.json({ listings, nextCursor, hasMore: listings.length === pageSize });
}

import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";
import { z } from "zod";

const createSchema = z.object({
  title: z.string().min(3).max(80),
  description: z.string().min(10).max(2000),
  pricePence: z.number().int().min(100),
  condition: z.string().min(2).max(30),
  category: z.string().min(2).max(50),
  brand: z.string().max(50).optional(),
  size: z.string().max(30).optional(),
  imageUrls: z.array(z.string().url()).max(10),
});

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = createSchema.parse(await req.json());

  const listing = await prisma.listing.create({
    data: {
      sellerId: (session as any).uid,
      title: body.title,
      description: body.description,
      pricePence: body.pricePence,
      condition: body.condition,
      category: body.category,
      brand: body.brand,
      size: body.size,
      images: { create: body.imageUrls.map((url, i) => ({ url, sortOrder: i })) },
    },
    include: { images: true },
  });

  return NextResponse.json({ listing });
}
