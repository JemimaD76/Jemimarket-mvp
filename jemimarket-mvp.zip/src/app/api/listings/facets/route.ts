import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";

function asPence(v: string | null) {
  if (!v) return undefined;
  const n = Number(v);
  if (!Number.isFinite(n) || n < 0) return undefined;
  return Math.round(n * 100);
}

function buildBaseWhere(sp: URLSearchParams) {
  const q = (sp.get("q") ?? "").trim();
  const category = (sp.get("category") ?? "").trim();
  const brand = (sp.get("brand") ?? "").trim();
  const size = (sp.get("size") ?? "").trim();
  const condition = (sp.get("condition") ?? "").trim();
  const minPrice = asPence(sp.get("minPrice"));
  const maxPrice = asPence(sp.get("maxPrice"));

  const where: any = {
    status: "ACTIVE",
    ...(q ? { OR: [
      { title: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
      { brand: { contains: q, mode: "insensitive" } },
    ] } : {}),
    ...(category ? { category: { contains: category, mode: "insensitive" } } : {}),
    ...(brand ? { brand: { contains: brand, mode: "insensitive" } } : {}),
    ...(size ? { size: { contains: size, mode: "insensitive" } } : {}),
    ...(condition ? { condition: { contains: condition, mode: "insensitive" } } : {}),
    ...((minPrice !== undefined || maxPrice !== undefined) ? { pricePence: { ...(minPrice !== undefined ? { gte: minPrice } : {}), ...(maxPrice !== undefined ? { lte: maxPrice } : {}) } } : {})
  };
  return { where };
}

function withoutField(where: any, field: string) {
  const w = { ...where };
  delete w[field];
  return w;
}

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const { where } = buildBaseWhere(searchParams);

  const [categories, brands, sizes, conditions] = await prisma.$transaction([
    prisma.listing.groupBy({ by: ["category"], where: withoutField(where, "category"), _count: { _all: true }, orderBy: { _count: { _all: "desc" } }, take: 50 }),
    prisma.listing.groupBy({ by: ["brand"], where: { ...withoutField(where, "brand"), brand: { not: null } }, _count: { _all: true }, orderBy: { _count: { _all: "desc" } }, take: 50 }),
    prisma.listing.groupBy({ by: ["size"], where: { ...withoutField(where, "size"), size: { not: null } }, _count: { _all: true }, orderBy: { _count: { _all: "desc" } }, take: 50 }),
    prisma.listing.groupBy({ by: ["condition"], where: withoutField(where, "condition"), _count: { _all: true }, orderBy: { _count: { _all: "desc" } }, take: 50 }),
  ]);

  return NextResponse.json({
    category: categories.map((x) => ({ value: x.category, count: x._count._all })),
    brand: brands.filter((x) => x.brand).map((x) => ({ value: x.brand as string, count: x._count._all })),
    size: sizes.filter((x) => x.size).map((x) => ({ value: x.size as string, count: x._count._all })),
    condition: conditions.map((x) => ({ value: x.condition, count: x._count._all })),
  });
}
