import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function POST(_: Request, { params }: { params: { listingId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid as string;

  await prisma.$transaction(async (tx) => {
    const existing = await tx.favorite.findUnique({ where: { userId_listingId: { userId: uid, listingId: params.listingId } } });
    if (!existing) {
      await tx.favorite.create({ data: { userId: uid, listingId: params.listingId } });
      await tx.listing.update({ where: { id: params.listingId }, data: { favoritesCount: { increment: 1 } } }).catch(() => null);
    }
  });

  return NextResponse.json({ ok: true });
}

export async function DELETE(_: Request, { params }: { params: { listingId: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid as string;

  await prisma.$transaction(async (tx) => {
    const existing = await tx.favorite.findUnique({ where: { userId_listingId: { userId: uid, listingId: params.listingId } } });
    if (existing) {
      await tx.favorite.delete({ where: { userId_listingId: { userId: uid, listingId: params.listingId } } }).catch(() => null);
      await tx.listing.update({ where: { id: params.listingId }, data: { favoritesCount: { decrement: 1 } } }).catch(() => null);
    }
  });

  return NextResponse.json({ ok: true });
}
