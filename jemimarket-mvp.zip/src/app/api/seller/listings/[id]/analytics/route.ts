import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function GET(_: Request, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid as string;

  const listing = await prisma.listing.findUnique({
    where: { id: params.id },
    include: { seller: { select: { id: true, handle: true } } },
  });

  if (!listing) return NextResponse.json({ error: "Not found" }, { status: 404 });
  if (listing.sellerId !== uid) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const [recentViews, recentFavorites, threads] = await prisma.$transaction([
    prisma.listingView.findMany({
      where: { listingId: params.id },
      include: { user: { select: { handle: true } } },
      orderBy: { createdAt: "desc" },
      take: 25,
    }),
    prisma.favorite.findMany({
      where: { listingId: params.id },
      include: { user: { select: { handle: true } } },
      orderBy: { createdAt: "desc" },
      take: 25,
    }),
    prisma.thread.findMany({
      where: { listingId: params.id },
      include: {
        buyer: { select: { handle: true } },
        messages: { orderBy: { createdAt: "desc" }, take: 1 },
      },
      orderBy: { createdAt: "desc" },
      take: 50,
    }),
  ]);

  return NextResponse.json({
    listing: {
      id: listing.id,
      title: listing.title,
      pricePence: listing.pricePence,
      status: listing.status,
      viewsCount: listing.viewsCount,
      favoritesCount: listing.favoritesCount,
      enquiriesCount: listing.enquiriesCount,
    },
    recentViews,
    recentFavorites,
    threads: threads.map(t => ({ id: t.id, buyer: t.buyer, lastMessage: t.messages[0] ?? null })),
  });
}
