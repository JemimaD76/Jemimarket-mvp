import { prisma } from "@/lib/db";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/authOptions";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const uid = (session as any).uid as string;

  const listings = await prisma.listing.findMany({
    where: { sellerId: uid },
    select: {
      id: true, title: true, pricePence: true, status: true, createdAt: true,
      viewsCount: true, favoritesCount: true, enquiriesCount: true
    },
    orderBy: { createdAt: "desc" },
    take: 500,
  });

  const summary = {
    activeListings: listings.filter(l => l.status === "ACTIVE").length,
    totalViews: listings.reduce((a, b) => a + (b.viewsCount ?? 0), 0),
    totalEnquiries: listings.reduce((a, b) => a + (b.enquiriesCount ?? 0), 0),
  };

  return NextResponse.json({ summary, listings });
}
