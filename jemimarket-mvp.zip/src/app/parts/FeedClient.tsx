"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "next/navigation";
import { highlightHtml, termsFromQuery } from "@/lib/highlight";

export default function FeedClient() {
  const sp = useSearchParams();
  const q = sp.get("q") ?? "";
  const terms = useMemo(() => termsFromQuery(q), [q]);

  const baseQuery = useMemo(() => {
    const qs = new URLSearchParams(sp.toString());
    qs.delete("cursor");
    if (!qs.get("pageSize")) qs.set("pageSize", "24");
    if (!qs.get("sort")) qs.set("sort", "newest");
    return qs.toString();
  }, [sp]);

  const [items, setItems] = useState<any[]>([]);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const isAutoLoadingRef = useRef(false);

  async function fetchPage(cursor: string | null, append: boolean) {
    const qs = new URLSearchParams(baseQuery);
    if (cursor) qs.set("cursor", cursor);

    const r = await fetch(`/api/listings?${qs.toString()}`, { cache: "no-store" });
    const j = await r.json();
    if (!r.ok) throw new Error(j.error ?? "Failed to load listings");

    setNextCursor(j.nextCursor ?? null);
    setHasMore(Boolean(j.hasMore));
    setItems((prev) => (append ? [...prev, ...(j.listings ?? [])] : (j.listings ?? [])));
  }

  useEffect(() => {
    setErr(null);
    setLoading(true);
    setItems([]);
    setNextCursor(null);
    setHasMore(false);

    fetchPage(null, false)
      .catch((e: any) => setErr(e.message ?? "Failed"))
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [baseQuery]);

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el) return;

    const obs = new IntersectionObserver(
      async (entries) => {
        const hit = entries.some((e) => e.isIntersecting);
        if (!hit) return;
        if (!hasMore || loading || loadingMore) return;
        if (!nextCursor) return;
        if (isAutoLoadingRef.current) return;

        isAutoLoadingRef.current = true;
        setLoadingMore(true);

        try {
          await fetchPage(nextCursor, true);
        } catch (e: any) {
          setErr(e.message ?? "Failed to load more");
        } finally {
          setLoadingMore(false);
          isAutoLoadingRef.current = false;
        }
      },
      { root: null, rootMargin: "600px", threshold: 0.01 }
    );

    obs.observe(el);
    return () => obs.disconnect();
  }, [hasMore, loading, loadingMore, nextCursor, baseQuery]);

  return (
    <div className="space-y-4">
      {err ? <div className="text-sm text-red-600">{err}</div> : null}

      {loading ? (
        <div className="text-sm text-gray-600">Loading…</div>
      ) : (
        <>
          <div className="text-sm text-gray-600">{items.length} loaded</div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {items.map((l: any) => (
              <a key={l.id} className="border rounded p-3 hover:shadow" href={`/listing/${l.id}`}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {l.images?.[0]?.url ? (
                  <img src={l.images[0].url} alt="" className="w-full h-48 object-cover rounded" />
                ) : (
                  <div className="w-full h-48 bg-gray-100 rounded" />
                )}
                <div className="mt-2 font-medium" dangerouslySetInnerHTML={{ __html: highlightHtml(l.title ?? "", terms) }} />
                {l.brand ? (
                  <div className="text-xs text-gray-600" dangerouslySetInnerHTML={{ __html: highlightHtml(l.brand, terms) }} />
                ) : null}
                <div className="text-sm text-gray-600">£{(l.pricePence / 100).toFixed(2)}</div>
                <div className="text-xs text-gray-500">@{l.seller.handle}</div>
              </a>
            ))}
          </div>

          <div ref={sentinelRef} />

          <div className="flex justify-center pt-2">
            <button
              disabled={!hasMore || loadingMore}
              className="px-4 py-2 rounded border hover:bg-gray-50 disabled:opacity-50"
              onClick={async () => {
                if (!nextCursor) return;
                setLoadingMore(true);
                try {
                  await fetchPage(nextCursor, true);
                } catch (e: any) {
                  setErr(e.message ?? "Failed to load more");
                } finally {
                  setLoadingMore(false);
                }
              }}
            >
              {loadingMore ? "Loading…" : hasMore ? "Load more" : "No more results"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
