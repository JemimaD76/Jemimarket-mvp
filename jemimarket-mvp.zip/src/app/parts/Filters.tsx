"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { useDebouncedValue } from "@/lib/useDebouncedValue";

type Facet = { value: string; count: number };
type Facets = { category: Facet[]; brand: Facet[]; size: Facet[]; condition: Facet[] };

function qp(sp: URLSearchParams) {
  return {
    q: sp.get("q") ?? "",
    category: sp.get("category") ?? "",
    brand: sp.get("brand") ?? "",
    size: sp.get("size") ?? "",
    condition: sp.get("condition") ?? "",
    minPrice: sp.get("minPrice") ?? "",
    maxPrice: sp.get("maxPrice") ?? "",
    sort: sp.get("sort") ?? "newest",
  };
}

export default function Filters() {
  const router = useRouter();
  const sp = useSearchParams();
  const initial = useMemo(() => qp(sp as any), [sp]);

  const [q, setQ] = useState(initial.q);
  const [category, setCategory] = useState(initial.category);
  const [brand, setBrand] = useState(initial.brand);
  const [size, setSize] = useState(initial.size);
  const [condition, setCondition] = useState(initial.condition);
  const [minPrice, setMinPrice] = useState(initial.minPrice);
  const [maxPrice, setMaxPrice] = useState(initial.maxPrice);
  const [sort, setSort] = useState(initial.sort);

  const dq = useDebouncedValue(q, 350);

  const [facets, setFacets] = useState<Facets>({ category: [], brand: [], size: [], condition: [] });

  useEffect(() => {
    const v = qp(sp as any);
    setQ(v.q);
    setCategory(v.category);
    setBrand(v.brand);
    setSize(v.size);
    setCondition(v.condition);
    setMinPrice(v.minPrice);
    setMaxPrice(v.maxPrice);
    setSort(v.sort);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp.toString()]);

  useEffect(() => {
    (async () => {
      const r = await fetch(`/api/listings/facets?${sp.toString()}`);
      const j = await r.json();
      if (r.ok) setFacets(j);
    })();
  }, [sp]);

  function setParam(params: URLSearchParams, k: string, v: string) {
    if (!v) params.delete(k);
    else params.set(k, v);
  }

  function pushUrl(next: Partial<ReturnType<typeof qp>>) {
    const params = new URLSearchParams(sp.toString());
    params.delete("cursor");

    setParam(params, "q", (next.q ?? dq).trim());
    setParam(params, "category", (next.category ?? category).trim());
    setParam(params, "brand", (next.brand ?? brand).trim());
    setParam(params, "size", (next.size ?? size).trim());
    setParam(params, "condition", (next.condition ?? condition).trim());
    setParam(params, "minPrice", (next.minPrice ?? minPrice).trim());
    setParam(params, "maxPrice", (next.maxPrice ?? maxPrice).trim());
    setParam(params, "sort", next.sort ?? sort);

    if (!params.get("pageSize")) params.set("pageSize", "24");

    router.push(`/?${params.toString()}`);
  }

  useEffect(() => {
    pushUrl({ q: dq.trim() });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dq]);

  function optionLabel(f: Facet) {
    return `${f.value} (${f.count})`;
  }

  return (
    <div className="border rounded p-3 space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-6 gap-2">
        <input className="border rounded px-3 py-2 md:col-span-2" placeholder="Search (live)…" value={q} onChange={(e) => setQ(e.target.value)} />

        <select className="border rounded px-3 py-2" value={category} onChange={(e) => { setCategory(e.target.value); pushUrl({ category: e.target.value }); }}>
          <option value="">Category (any)</option>
          {facets.category.map((f) => <option key={f.value} value={f.value}>{optionLabel(f)}</option>)}
        </select>

        <select className="border rounded px-3 py-2" value={brand} onChange={(e) => { setBrand(e.target.value); pushUrl({ brand: e.target.value }); }}>
          <option value="">Brand (any)</option>
          {facets.brand.map((f) => <option key={f.value} value={f.value}>{optionLabel(f)}</option>)}
        </select>

        <select className="border rounded px-3 py-2" value={size} onChange={(e) => { setSize(e.target.value); pushUrl({ size: e.target.value }); }}>
          <option value="">Size (any)</option>
          {facets.size.map((f) => <option key={f.value} value={f.value}>{optionLabel(f)}</option>)}
        </select>

        <select className="border rounded px-3 py-2" value={condition} onChange={(e) => { setCondition(e.target.value); pushUrl({ condition: e.target.value }); }}>
          <option value="">Condition (any)</option>
          {facets.condition.map((f) => <option key={f.value} value={f.value}>{optionLabel(f)}</option>)}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-6 gap-2 items-center">
        <input className="border rounded px-3 py-2" placeholder="Min £" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} onBlur={() => pushUrl({ minPrice })} />
        <input className="border rounded px-3 py-2" placeholder="Max £" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} onBlur={() => pushUrl({ maxPrice })} />

        <select className="border rounded px-3 py-2 md:col-span-2" value={sort} onChange={(e) => { setSort(e.target.value); pushUrl({ sort: e.target.value }); }}>
          <option value="newest">Newest</option>
          <option value="relevance">Relevance</option>
          <option value="price_asc">Price (low → high)</option>
          <option value="price_desc">Price (high → low)</option>
        </select>

        <button className="px-4 py-2 rounded border hover:bg-gray-50" onClick={() => router.push("/")} type="button">
          Clear
        </button>

        <div className="text-xs text-gray-600 md:text-right">Search updates after 350ms.</div>
      </div>
    </div>
  );
}
