"use client";

import Nav from "@/components/Nav";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function SignupPage() {
  const [email, setEmail] = useState("");
  const [handle, setHandle] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-md p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Create account</h1>

        <form className="space-y-3" onSubmit={async (e) => {
          e.preventDefault();
          setErr(null);
          setLoading(true);
          try {
            const r = await fetch("/api/auth/signup", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ email, handle, password }),
            });
            const j = await r.json();
            if (!r.ok) throw new Error(j.error ?? "Signup failed");
            router.push("/login");
          } catch (e: any) {
            setErr(e.message);
          } finally {
            setLoading(false);
          }
        }}>
          <label className="block text-sm">Email
            <input className="mt-1 w-full border rounded px-3 py-2" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block text-sm">Handle (username)
            <input className="mt-1 w-full border rounded px-3 py-2" value={handle} onChange={(e) => setHandle(e.target.value)} />
          </label>
          <label className="block text-sm">Password
            <input type="password" className="mt-1 w-full border rounded px-3 py-2" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>

          {err ? <div className="text-sm text-red-600">{err}</div> : null}

          <button disabled={loading} className="w-full px-4 py-2 rounded bg-black text-white hover:opacity-90 disabled:opacity-50">
            {loading ? "Creating..." : "Sign up"}
          </button>
        </form>

        <p className="text-sm text-gray-600">Already have an account? <Link className="underline" href="/login">Log in</Link></p>
      </main>
    </>
  );
}
