import Nav from "@/components/Nav";
import ListingActions from "./parts/ListingActions";
import ViewPing from "./parts/ViewPing";

export default async function ListingPage({ params }: { params: { id: string } }) {
  const res = await fetch(`http://localhost:3000/api/listings/${params.id}`, { cache: "no-store" });
  const { listing } = await res.json();

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <ViewPing listingId={listing.id} />
        <a href="/" className="text-sm underline">← Back</a>

        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1 space-y-3">
            <h1 className="text-2xl font-semibold">{listing.title}</h1>
            <div className="text-gray-700">£{(listing.pricePence / 100).toFixed(2)}</div>
            <div className="text-sm text-gray-600">Seller: @{listing.seller.handle}</div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {listing.images.map((img: any) => (
                // eslint-disable-next-line @next/next/no-img-element
                <img key={img.id} src={img.url} alt="" className="w-full h-56 object-cover rounded border" />
              ))}
            </div>

            <p className="whitespace-pre-wrap">{listing.description}</p>
          </div>

          <aside className="w-full md:w-80 border rounded p-4 space-y-3 h-fit">
            <div className="text-lg font-semibold">£{(listing.pricePence / 100).toFixed(2)}</div>
            <div className="text-sm text-gray-600">
              Condition: {listing.condition}<br />
              Category: {listing.category}<br />
              {listing.brand ? <>Brand: {listing.brand}<br /></> : null}
              {listing.size ? <>Size: {listing.size}<br /></> : null}
            </div>

            <ListingActions listingId={listing.id} sellerHandle={listing.seller.handle} />

            <a className="text-sm underline text-gray-700" href="/report">Report something</a>
          </aside>
        </div>
      </main>
    </>
  );
}
