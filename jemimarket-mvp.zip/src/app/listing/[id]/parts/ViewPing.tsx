"use client";

import { useEffect } from "react";

export default function ViewPing({ listingId }: { listingId: string }) {
  useEffect(() => {
    fetch(`/api/listings/${listingId}/view`, { method: "POST" }).catch(() => null);
  }, [listingId]);
  return null;
}
