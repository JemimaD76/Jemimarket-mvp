"use client";

import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";

export default function ListingActions({ listingId, sellerHandle }: { listingId: string; sellerHandle: string }) {
  const { data: session } = useSession();
  const router = useRouter();
  const [favLoading, setFavLoading] = useState(false);
  const [msg, setMsg] = useState("Hi! Is this still available?");
  const [msgLoading, setMsgLoading] = useState(false);

  async function requireAuth(pathAfter: string) {
    if (!session) {
      router.push(`/login?callbackUrl=${encodeURIComponent(pathAfter)}`);
      return false;
    }
    return true;
  }

  return (
    <div className="space-y-3">
      <button
        disabled={favLoading}
        className="w-full px-4 py-2 rounded border hover:bg-gray-50 disabled:opacity-50"
        onClick={async () => {
          if (!(await requireAuth(`/listing/${listingId}`))) return;
          setFavLoading(true);
          await fetch(`/api/favorites/${listingId}`, { method: "POST" });
          setFavLoading(false);
          alert("Saved to favorites.");
        }}
      >
        Save to favorites
      </button>

      <div className="border rounded p-3 space-y-2">
        <div className="text-sm font-medium">Message @{sellerHandle}</div>
        <textarea className="w-full border rounded px-2 py-2 text-sm min-h-[80px]" value={msg} onChange={(e) => setMsg(e.target.value)} />
        <button
          disabled={msgLoading}
          className="w-full px-3 py-2 rounded bg-black text-white hover:opacity-90 disabled:opacity-50"
          onClick={async () => {
            if (!(await requireAuth(`/listing/${listingId}`))) return;
            setMsgLoading(true);
            const r = await fetch("/api/threads", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ listingId, message: msg }),
            });
            const j = await r.json();
            setMsgLoading(false);
            if (!r.ok) return alert(j.error ?? "Failed to send");
            router.push(`/inbox/${j.threadId}`);
          }}
        >
          Send message
        </button>
      </div>
    </div>
  );
}
