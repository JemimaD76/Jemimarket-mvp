"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function InboxPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [threads, setThreads] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/inbox")}`); return; }
    (async () => {
      const r = await fetch("/api/threads");
      const j = await r.json();
      if (!r.ok) setErr(j.error ?? "Failed to load inbox");
      else setThreads(j.threads ?? []);
    })();
  }, [session, status, router]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Inbox</h1>
        {err ? <div className="text-sm text-red-600">{err}</div> : null}

        <div className="space-y-3">
          {threads.map((t) => {
            const last = t.messages?.[0];
            return (
              <a key={t.id} href={`/inbox/${t.id}`} className="block border rounded p-3 hover:bg-gray-50">
                <div className="flex items-center gap-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {t.listing.images?.[0]?.url ? (
                    <img src={t.listing.images[0].url} alt="" className="h-14 w-14 object-cover rounded border" />
                  ) : (
                    <div className="h-14 w-14 rounded bg-gray-100 border" />
                  )}
                  <div className="flex-1">
                    <div className="font-medium">{t.listing.title}</div>
                    <div className="text-sm text-gray-600">{last ? last.body : "No messages yet"}</div>
                  </div>
                  <div className="text-sm text-gray-600">£{(t.listing.pricePence / 100).toFixed(2)}</div>
                </div>
              </a>
            );
          })}
        </div>
      </main>
    </>
  );
}
