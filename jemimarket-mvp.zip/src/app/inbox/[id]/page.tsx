"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function ThreadPage({ params }: { params: { id: string } }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [thread, setThread] = useState<any | null>(null);
  const [body, setBody] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [sending, setSending] = useState(false);

  async function load() {
    const r = await fetch(`/api/threads/${params.id}`);
    const j = await r.json();
    if (!r.ok) setErr(j.error ?? "Failed to load thread");
    else setThread(j.thread);
  }

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent(`/inbox/${params.id}`)}`); return; }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-3xl p-6 space-y-4">
        <a className="text-sm underline" href="/inbox">← Back to inbox</a>

        {err ? <div className="text-sm text-red-600">{err}</div> : null}
        {!thread ? null : (
          <>
            <div className="border rounded p-3 flex items-center gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              {thread.listing.images?.[0]?.url ? (
                <img src={thread.listing.images[0].url} alt="" className="h-16 w-16 object-cover rounded border" />
              ) : (
                <div className="h-16 w-16 rounded bg-gray-100 border" />
              )}
              <div className="flex-1">
                <div className="font-medium">{thread.listing.title}</div>
                <div className="text-sm text-gray-600">
                  £{(thread.listing.pricePence / 100).toFixed(2)} · Seller @{thread.seller.handle}
                </div>
              </div>
              <a className="text-sm underline" href={`/listing/${thread.listing.id}`}>View listing</a>
            </div>

            <div className="border rounded p-3 space-y-2">
              {thread.messages.map((m: any) => (
                <div key={m.id} className="text-sm">
                  <span className="font-medium">@{m.sender.handle}</span>: <span className="text-gray-800">{m.body}</span>
                </div>
              ))}
            </div>

            <form className="flex gap-2" onSubmit={async (e) => {
              e.preventDefault();
              setErr(null);
              if (!body.trim()) return;
              setSending(true);
              const r = await fetch(`/api/threads/${params.id}/messages`, {
                method: "POST",
                headers: { "content-type": "application/json" },
                body: JSON.stringify({ body }),
              });
              const j = await r.json();
              setSending(false);
              if (!r.ok) return setErr(j.error ?? "Failed to send");
              setBody("");
              await load();
            }}>
              <input className="flex-1 border rounded px-3 py-2" value={body} onChange={(e) => setBody(e.target.value)} placeholder="Write a message…" />
              <button className="px-4 py-2 rounded bg-black text-white disabled:opacity-50" disabled={sending}>Send</button>
            </form>
          </>
        )}
      </main>
    </>
  );
}
