"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function AdminReportsPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [reports, setReports] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  async function load() {
    const r = await fetch("/api/admin/reports");
    const j = await r.json();
    if (!r.ok) setErr(j.error ?? "Failed to load reports");
    else setReports(j.reports ?? []);
  }

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/admin/reports")}`); return; }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Admin · Reports</h1>
        {err ? <div className="text-sm text-red-600">{err}</div> : null}

        <div className="space-y-3">
          {reports.map((r) => (
            <div key={r.id} className="border rounded p-3 space-y-2">
              <div className="text-sm text-gray-600">Reporter: @{r.reporter.handle} · Status: {r.status}</div>
              <div className="text-sm">{r.reason}</div>
              {r.listing ? (
                <div className="flex items-center gap-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  {r.listing.images?.[0]?.url ? (
                    <img src={r.listing.images[0].url} alt="" className="h-14 w-14 object-cover rounded border" />
                  ) : (
                    <div className="h-14 w-14 rounded bg-gray-100 border" />
                  )}
                  <div className="flex-1">
                    <div className="font-medium">{r.listing.title}</div>
                    <div className="text-sm text-gray-600">Status: {r.listing.status}</div>
                  </div>
                  <a className="underline text-sm" href={`/listing/${r.listing.id}`}>View</a>
                  <button className="px-3 py-2 rounded border hover:bg-gray-50 text-sm" onClick={async () => {
                    const ok = confirm("Hide this listing?");
                    if (!ok) return;
                    await fetch(`/api/admin/listings/${r.listing.id}/hide`, { method: "POST" });
                    await load();
                  }}>Hide listing</button>
                </div>
              ) : (
                <div className="text-sm text-gray-600">No listing attached.</div>
              )}
            </div>
          ))}
        </div>
      </main>
    </>
  );
}
