import Nav from "@/components/Nav";
import Filters from "@/app/parts/Filters";
import FeedClient from "@/app/parts/FeedClient";

export default function Home() {
  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Marketplace</h1>
        <Filters />
        <FeedClient />
      </main>
    </>
  );
}
