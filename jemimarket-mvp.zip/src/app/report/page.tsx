"use client";

import Nav from "@/components/Nav";
import { useState } from "react";

export default function ReportPage() {
  const [listingId, setListingId] = useState("");
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-md p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Report</h1>

        <form className="space-y-3" onSubmit={async (e) => {
          e.preventDefault();
          setErr(null); setMsg(null);
          const r = await fetch("/api/reports", {
            method: "POST",
            headers: { "content-type": "application/json" },
            body: JSON.stringify({ listingId: listingId || undefined, reason }),
          });
          const j = await r.json();
          if (!r.ok) setErr(j.error ?? "Failed to submit");
          else setMsg("Report submitted. Thanks.");
        }}>
          <label className="block text-sm">Listing ID (optional)
            <input className="mt-1 w-full border rounded px-3 py-2" value={listingId} onChange={(e) => setListingId(e.target.value)} />
          </label>
          <label className="block text-sm">Reason
            <textarea className="mt-1 w-full border rounded px-3 py-2 min-h-[120px]" value={reason} onChange={(e) => setReason(e.target.value)} />
          </label>
          {err ? <div className="text-sm text-red-600">{err}</div> : null}
          {msg ? <div className="text-sm text-green-700">{msg}</div> : null}
          <button className="px-4 py-2 rounded bg-black text-white hover:opacity-90">Submit</button>
        </form>
      </main>
    </>
  );
}
