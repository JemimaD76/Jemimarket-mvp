"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

function OrderCard({ o, mode }: { o: any; mode: "BOUGHT" | "SOLD" }) {
  const counterparty = mode === "BOUGHT" ? o.seller?.handle : o.buyer?.handle;
  return (
    <div className="border rounded p-3 flex gap-3">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      {o.listing.images?.[0]?.url ? (
        <img src={o.listing.images[0].url} alt="" className="h-16 w-16 object-cover rounded border" />
      ) : (
        <div className="h-16 w-16 rounded bg-gray-100 border" />
      )}
      <div className="flex-1">
        <div className="font-medium">{o.listing.title}</div>
        <div className="text-sm text-gray-600">
          £{((o.amountPence + o.feePence + o.shippingPence) / 100).toFixed(2)} · {mode === "BOUGHT" ? "Seller" : "Buyer"} @{counterparty}
        </div>
        <div className="text-sm text-gray-600">Status: {o.status}</div>
      </div>
      <a className="underline text-sm h-fit" href={`/listing/${o.listing.id}`}>View</a>
    </div>
  );
}

export default function OrdersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [bought, setBought] = useState<any[]>([]);
  const [sold, setSold] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/orders")}`); return; }
    (async () => {
      const r = await fetch("/api/orders");
      const j = await r.json();
      if (!r.ok) setErr(j.error ?? "Failed to load orders");
      else { setBought(j.bought ?? []); setSold(j.sold ?? []); }
    })();
  }, [session, status, router]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-6">
        <h1 className="text-2xl font-semibold">Orders</h1>
        {err ? <div className="text-sm text-red-600">{err}</div> : null}

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">Bought</h2>
          <div className="space-y-3">{bought.map((o) => <OrderCard key={o.id} o={o} mode="BOUGHT" />)}</div>
        </section>

        <section className="space-y-3">
          <h2 className="text-xl font-semibold">Sold</h2>
          <div className="space-y-3">{sold.map((o) => <OrderCard key={o.id} o={o} mode="SOLD" />)}</div>
        </section>
      </main>
    </>
  );
}
