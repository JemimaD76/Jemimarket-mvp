"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";

export default function SellerListingAnalytics({ params }: { params: { id: string } }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [data, setData] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent(`/seller/listings/${params.id}`)}`); return; }
    (async () => {
      const r = await fetch(`/api/seller/listings/${params.id}/analytics`);
      const j = await r.json();
      if (!r.ok) setErr(j.error ?? "Failed to load analytics");
      else setData(j);
    })();
  }, [session, status, router, params.id]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <a className="text-sm underline" href="/seller/dashboard">← Back to dashboard</a>
        <h1 className="text-2xl font-semibold">Listing Analytics</h1>

        {err ? <div className="text-sm text-red-600">{err}</div> : null}
        {!data ? <div className="text-sm text-gray-600">Loading…</div> : (
          <>
            <div className="border rounded p-4 space-y-1">
              <div className="font-medium">{data.listing.title}</div>
              <div className="text-sm text-gray-600">£{(data.listing.pricePence/100).toFixed(2)} · {data.listing.status}</div>
              <div className="text-sm text-gray-600">Views: {data.listing.viewsCount} · Favorites: {data.listing.favoritesCount} · Enquiries: {data.listing.enquiriesCount}</div>
              <a className="underline text-sm" href={`/listing/${data.listing.id}`}>Open public listing</a>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="border rounded p-4 space-y-2">
                <div className="font-semibold">Recent viewers</div>
                {data.recentViews.length ? data.recentViews.map((v: any) => (
                  <div key={v.id} className="text-sm text-gray-700">
                    {v.user ? `@${v.user.handle}` : "Anonymous"} · {new Date(v.createdAt).toLocaleString()}
                  </div>
                )) : <div className="text-sm text-gray-600">No views yet.</div>}
              </div>

              <div className="border rounded p-4 space-y-2">
                <div className="font-semibold">Recent favoriters</div>
                {data.recentFavorites.length ? data.recentFavorites.map((f: any) => (
                  <div key={f.userId + "_" + f.createdAt} className="flex items-center justify-between text-sm">
                    <span>@{f.user.handle}</span>
                    <a className="underline" href={`/inbox?startListing=${data.listing.id}&to=${f.user.handle}`}>Message</a>
                  </div>
                )) : <div className="text-sm text-gray-600">No favorites yet.</div>}
              </div>
            </div>

            <div className="border rounded p-4 space-y-2">
              <div className="font-semibold">Enquiries (threads)</div>
              {data.threads.length ? data.threads.map((t: any) => (
                <div key={t.id} className="flex items-center justify-between text-sm border-t pt-2">
                  <div>
                    <div className="font-medium">@{t.buyer.handle}</div>
                    <div className="text-gray-600">{t.lastMessage?.body ?? ""}</div>
                  </div>
                  <a className="underline" href={`/inbox/${t.id}`}>Open chat</a>
                </div>
              )) : <div className="text-sm text-gray-600">No enquiries yet.</div>}
            </div>
          </>
        )}
      </main>
    </>
  );
}
