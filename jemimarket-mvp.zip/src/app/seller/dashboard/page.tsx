"use client";

import Nav from "@/components/Nav";
import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

type SortKey = "createdAt" | "views" | "favorites" | "enquiries";

export default function SellerDashboardPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [data, setData] = useState<any | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [sort, setSort] = useState<SortKey>("views");

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/seller/dashboard")}`); return; }
    (async () => {
      const r = await fetch("/api/seller/dashboard");
      const j = await r.json();
      if (!r.ok) setErr(j.error ?? "Failed to load dashboard");
      else setData(j);
    })();
  }, [session, status, router]);

  const rows = useMemo(() => {
    const ls = (data?.listings ?? []) as any[];
    const sorted = [...ls];
    sorted.sort((a, b) => {
      if (sort === "createdAt") return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      if (sort === "views") return (b.viewsCount ?? 0) - (a.viewsCount ?? 0);
      if (sort === "favorites") return (b.favoritesCount ?? 0) - (a.favoritesCount ?? 0);
      return (b.enquiriesCount ?? 0) - (a.enquiriesCount ?? 0);
    });
    return sorted;
  }, [data, sort]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Seller Analytics</h1>
        <p className="text-sm text-gray-600">
          This dashboard shows per-listing: views, favorites, and enquiries (first message threads).
        </p>

        {err ? <div className="text-sm text-red-600">{err}</div> : null}
        {!data ? <div className="text-sm text-gray-600">Loading…</div> : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="border rounded p-3">
                <div className="text-sm text-gray-600">Active listings</div>
                <div className="text-2xl font-semibold">{data.summary.activeListings}</div>
              </div>
              <div className="border rounded p-3">
                <div className="text-sm text-gray-600">Total views</div>
                <div className="text-2xl font-semibold">{data.summary.totalViews}</div>
              </div>
              <div className="border rounded p-3">
                <div className="text-sm text-gray-600">Total enquiries</div>
                <div className="text-2xl font-semibold">{data.summary.totalEnquiries}</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <span className="text-sm text-gray-700">Sort by:</span>
              <select className="border rounded px-3 py-2 text-sm" value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
                <option value="views">Most viewed</option>
                <option value="favorites">Most favorited</option>
                <option value="enquiries">Most enquiries</option>
                <option value="createdAt">Newest</option>
              </select>
              <a className="ml-auto underline text-sm" href="/sell">+ New listing</a>
            </div>

            <div className="border rounded overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="text-left p-2">Listing</th>
                    <th className="text-right p-2">Views</th>
                    <th className="text-right p-2">Favorites</th>
                    <th className="text-right p-2">Enquiries</th>
                    <th className="text-right p-2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {rows.map((l) => (
                    <tr key={l.id} className="border-t">
                      <td className="p-2">
                        <div className="font-medium">{l.title}</div>
                        <div className="text-xs text-gray-600">£{(l.pricePence/100).toFixed(2)} · {l.status}</div>
                      </td>
                      <td className="p-2 text-right">{l.viewsCount}</td>
                      <td className="p-2 text-right">{l.favoritesCount}</td>
                      <td className="p-2 text-right">{l.enquiriesCount}</td>
                      <td className="p-2 text-right">
                        <a className="underline" href={`/seller/listings/${l.id}`}>View analytics</a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </main>
    </>
  );
}
