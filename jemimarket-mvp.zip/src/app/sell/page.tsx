"use client";

import Nav from "@/components/Nav";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useState } from "react";
import ImageUploader from "@/components/ImageUploader";

export default function SellPage() {
  const { data: session, status } = useSession();
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("10.00");
  const [condition, setCondition] = useState("Good");
  const [category, setCategory] = useState("Clothing");
  const [brand, setBrand] = useState("");
  const [size, setSize] = useState("");
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  if (status === "loading") return null;
  if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/sell")}`); return null; }

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-2xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Sell an item</h1>

        <form className="space-y-3" onSubmit={async (e) => {
          e.preventDefault();
          setErr(null);
          setLoading(true);
          try {
            const pricePence = Math.round(parseFloat(price) * 100);
            const r = await fetch("/api/listings", {
              method: "POST",
              headers: { "content-type": "application/json" },
              body: JSON.stringify({ title, description, pricePence, condition, category, brand: brand || undefined, size: size || undefined, imageUrls }),
            });
            const j = await r.json();
            if (!r.ok) throw new Error(j.error ?? "Failed to create listing");
            router.push(`/listing/${j.listing.id}`);
          } catch (e: any) {
            setErr(e.message);
          } finally {
            setLoading(false);
          }
        }}>
          <label className="block text-sm">Title
            <input className="mt-1 w-full border rounded px-3 py-2" value={title} onChange={(e) => setTitle(e.target.value)} />
          </label>

          <label className="block text-sm">Description
            <textarea className="mt-1 w-full border rounded px-3 py-2 min-h-[120px]" value={description} onChange={(e) => setDescription(e.target.value)} />
          </label>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="block text-sm">Price (GBP)
              <input className="mt-1 w-full border rounded px-3 py-2" value={price} onChange={(e) => setPrice(e.target.value)} />
            </label>
            <label className="block text-sm">Condition
              <input className="mt-1 w-full border rounded px-3 py-2" value={condition} onChange={(e) => setCondition(e.target.value)} />
            </label>
            <label className="block text-sm">Category
              <input className="mt-1 w-full border rounded px-3 py-2" value={category} onChange={(e) => setCategory(e.target.value)} />
            </label>
            <label className="block text-sm">Brand (optional)
              <input className="mt-1 w-full border rounded px-3 py-2" value={brand} onChange={(e) => setBrand(e.target.value)} />
            </label>
            <label className="block text-sm">Size (optional)
              <input className="mt-1 w-full border rounded px-3 py-2" value={size} onChange={(e) => setSize(e.target.value)} />
            </label>
          </div>

          <div className="border rounded p-3 space-y-2">
            <div className="text-sm font-medium">Images</div>
            <ImageUploader value={imageUrls} onChange={setImageUrls} max={10} />
          </div>

          {err ? <div className="text-sm text-red-600">{err}</div> : null}

          <button className="px-4 py-2 rounded bg-black text-white hover:opacity-90 disabled:opacity-50" disabled={loading}>
            {loading ? "Creating..." : "Create listing"}
          </button>
        </form>
      </main>
    </>
  );
}
