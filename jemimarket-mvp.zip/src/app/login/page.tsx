"use client";

import Nav from "@/components/Nav";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const sp = useSearchParams();
  const callbackUrl = sp.get("callbackUrl") ?? "/";

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-md p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Log in</h1>

        <form className="space-y-3" onSubmit={async (e) => {
          e.preventDefault();
          setErr(null);
          setLoading(true);
          const res = await signIn("credentials", { email, password, redirect: false });
          setLoading(false);
          if (res?.error) setErr("Invalid email or password");
          else router.push(callbackUrl);
        }}>
          <label className="block text-sm">Email
            <input className="mt-1 w-full border rounded px-3 py-2" value={email} onChange={(e) => setEmail(e.target.value)} />
          </label>
          <label className="block text-sm">Password
            <input type="password" className="mt-1 w-full border rounded px-3 py-2" value={password} onChange={(e) => setPassword(e.target.value)} />
          </label>

          {err ? <div className="text-sm text-red-600">{err}</div> : null}

          <button className="w-full px-4 py-2 rounded bg-black text-white hover:opacity-90 disabled:opacity-50" disabled={loading}>
            {loading ? "Signing in..." : "Log in"}
          </button>
        </form>

        <p className="text-sm text-gray-600">No account? <Link className="underline" href="/signup">Sign up</Link></p>
      </main>
    </>
  );
}
