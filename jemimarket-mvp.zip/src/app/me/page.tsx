"use client";

import Nav from "@/components/Nav";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";

export default function MePage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [me, setMe] = useState<any | null>(null);
  const [listings, setListings] = useState<any[]>([]);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    if (status === "loading") return;
    if (!session) { router.push(`/login?callbackUrl=${encodeURIComponent("/me")}`); return; }
    (async () => {
      const r = await fetch("/api/me");
      const j = await r.json();
      if (!r.ok) setErr(j.error ?? "Failed to load profile");
      else { setMe(j.user); setListings(j.listings ?? []); }
    })();
  }, [session, status, router]);

  return (
    <>
      <Nav />
      <main className="mx-auto max-w-5xl p-6 space-y-4">
        <h1 className="text-2xl font-semibold">Profile</h1>
        {err ? <div className="text-sm text-red-600">{err}</div> : null}
        {!me ? null : (
          <div className="border rounded p-4 space-y-2">
            <div className="font-medium">@{me.handle}</div>
            <div className="text-sm text-gray-600">{me.email}</div>
            <div className="text-sm text-gray-600">Role: {me.role}</div>
          </div>
        )}

        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold">My listings</h2>
          <a className="underline" href="/sell">+ Create listing</a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {listings.map((l) => (
            <a key={l.id} className="border rounded p-3 hover:shadow" href={`/listing/${l.id}`}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              {l.images?.[0]?.url ? (
                <img src={l.images[0].url} alt="" className="w-full h-48 object-cover rounded" />
              ) : (
                <div className="w-full h-48 bg-gray-100 rounded" />
              )}
              <div className="mt-2 font-medium">{l.title}</div>
              <div className="text-sm text-gray-600">£{(l.pricePence / 100).toFixed(2)}</div>
              <div className="text-xs text-gray-500">Status: {l.status}</div>
            </a>
          ))}
        </div>
      </main>
    </>
  );
}
