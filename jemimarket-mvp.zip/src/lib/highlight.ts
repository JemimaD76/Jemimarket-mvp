export function escapeHtml(s: string) {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function escapeRegExp(s: string) {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

export function termsFromQuery(q: string, maxTerms = 6) {
  return q
    .trim()
    .split(/\s+/)
    .map((t) => t.replace(/[^\p{L}\p{N}_-]/gu, ""))
    .filter((t) => t.length >= 2)
    .slice(0, maxTerms);
}

export function highlightHtml(text: string, terms: string[]) {
  const safe = escapeHtml(text ?? "");
  if (!terms.length) return safe;
  const pattern = terms.map(escapeRegExp).join("|");
  const re = new RegExp(`(${pattern})`, "gi");
  return safe.replace(re, "<mark>$1</mark>");
}
